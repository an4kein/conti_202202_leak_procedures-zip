# conti_202202_leak_procedures
This repository contains procedures found in the Feb 2022 conti leaks. They were taken from the "manual_teams_c" rocketchat channel in the leak and posted on may 10th, 2021 in the channel.

See https://twitter.com/res260/status/1498103308711518215 for more details on the conti leak.

**This information is meant to help defenders and see exactly how a ransomware group operates and how they write their procedures for other members to follow. It is NOT intended to be used for malicious purposes.**
